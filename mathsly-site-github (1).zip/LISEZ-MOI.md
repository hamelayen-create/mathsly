# Mathsly — Site de révision de mathématiques

Site statique (HTML/JavaScript) couvrant les programmes de mathématiques
de la 6e à la Terminale : cours, QCM, exercices corrigés.

## Structure du dépôt

    index.html              → l'interface élève (à ouvrir)
    contenu/MATHSLY_6e.js   → contenu de 6e
    contenu/MATHSLY_5e.js   → contenu de 5e
    contenu/MATHSLY_4e.js   → contenu de 4e
    contenu/MATHSLY_3e.js   → contenu de 3e
    contenu/MATHSLY_2de.js  → contenu de 2de
    contenu/MATHSLY_1re.js  → contenu de 1re
    contenu/MATHSLY_Tle.js  → contenu de Terminale

Les fichiers de contenu sont chargés à la demande, quand l'élève
ouvre un niveau. Chaque fichier peut être modifié indépendamment.

## Mise en ligne (GitHub Pages)

1. Créer un dépôt public (par exemple `mathsly`)
2. Déposer tous les fichiers de ce dossier à la racine du dépôt
3. Settings > Pages > Source : `main` / `root` > Save
4. Attendre une minute, puis ouvrir https://VOTRE-PSEUDO.github.io/mathsly/

## Ajouter le site à l'écran d'accueil (iPad / iPhone)

Ouvrir l'URL dans Safari, bouton Partager, puis « Sur l'écran d'accueil ».
Le site s'ouvre alors en plein écran, comme une application.

## Contenu

| Classe | Chapitres | Leçons | Exercices |
|---|---|---|---|
| 6e  | 6  | 12 | 183 |
| 5e  | 7  | 14 | 225 |
| 4e  | 7  | 14 | 238 |
| 3e  | 6  | 12 | 202 |
| 2de | 10 | 20 | 310 |
| 1re | 10 | 22 | 299 |
| Tle | 14 | 33 | 435 |
| **Total** | **60** | **127** | **1 892** |

## Données

Aucune donnée personnelle n'est collectée ni transmise.
La progression est enregistrée dans le navigateur de l'élève.
